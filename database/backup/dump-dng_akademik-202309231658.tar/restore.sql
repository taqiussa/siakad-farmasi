--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.9 (Homebrew)
-- Dumped by pg_dump version 14.9 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE dng_akademik;
--
-- Name: dng_akademik; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE dng_akademik WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'C';


\connect dng_akademik

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: perwalian; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA perwalian;


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: siakad; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA siakad;


--
-- Name: SCHEMA siakad; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA siakad IS 'standard public schema';


--
-- Name: skripsi; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA skripsi;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: master_dosen_wali; Type: TABLE; Schema: perwalian; Owner: -
--

CREATE TABLE perwalian.master_dosen_wali (
    id_master_dosen_wali uuid NOT NULL,
    id_prodi uuid NOT NULL,
    nama_program_studi character varying,
    id_semester character(5) NOT NULL,
    id_dosen uuid NOT NULL,
    id_registrasi_mahasiswa uuid NOT NULL,
    nama_mahasiswa character varying(24),
    nim character(24)
);


--
-- Name: penguji_mahasiswa; Type: TABLE; Schema: perwalian; Owner: -
--

CREATE TABLE perwalian.penguji_mahasiswa (
    id_penguji_mahasiswa uuid NOT NULL,
    id_mahasiswa_skripsi uuid NOT NULL,
    id_kategori_kegiatan character(6) NOT NULL,
    id_dosen uuid NOT NULL,
    penguji_ke integer NOT NULL
);


--
-- Name: COLUMN penguji_mahasiswa.id_kategori_kegiatan; Type: COMMENT; Schema: perwalian; Owner: -
--

COMMENT ON COLUMN perwalian.penguji_mahasiswa.id_kategori_kegiatan IS 'Web Service: GetKategoriKegiatan';


--
-- Name: pesan_perwalian; Type: TABLE; Schema: perwalian; Owner: -
--

CREATE TABLE perwalian.pesan_perwalian (
    id_pesan_perwalian uuid NOT NULL,
    id_tran_perwalian uuid NOT NULL,
    id_dosen uuid,
    id_registrasi_mahasiswa uuid,
    pesan character varying,
    tgl_pesan time without time zone DEFAULT CURRENT_TIME
);


--
-- Name: tran_perwalian; Type: TABLE; Schema: perwalian; Owner: -
--

CREATE TABLE perwalian.tran_perwalian (
    id_tran_perwalian uuid NOT NULL,
    id_prodi uuid NOT NULL,
    nama_program_studi character varying,
    id_semester character(5) NOT NULL,
    id_waktu_perwalian uuid NOT NULL,
    tgl_bimbingan time without time zone DEFAULT CURRENT_TIME NOT NULL,
    pertemuan integer NOT NULL
);


--
-- Name: waktu_perwalian; Type: TABLE; Schema: perwalian; Owner: -
--

CREATE TABLE perwalian.waktu_perwalian (
    id_waktu_perwalian uuid NOT NULL,
    nama_perwalian character varying,
    id_prodi uuid,
    nama_program_studi character varying,
    id_semester character(5),
    tgl_mulai time without time zone,
    tgl_selesai time without time zone,
    pertemuan integer
);


--
-- Name: absensi_perkuliahan; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.absensi_perkuliahan (
    id_absensi_perkuliahan uuid NOT NULL,
    id_prodi uuid NOT NULL,
    nama_program_studi character varying,
    id_semester character(5) NOT NULL,
    id_master_kegiatan_perkuliahan uuid NOT NULL,
    tgl_absensi_mulai time without time zone NOT NULL,
    tgl_absensi_selesai time without time zone NOT NULL,
    nama_absensi character varying
);


--
-- Name: aktivitas_perkuliahan_mahasiswa; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.aktivitas_perkuliahan_mahasiswa (
    id_aktivitas_perkuliahan_mahasiswa uuid NOT NULL,
    id_prodi uuid NOT NULL,
    nama_program_studi character varying,
    id_semester character(5) NOT NULL,
    id_status_mahasiswa character(1) NOT NULL,
    ips double precision,
    ipk double precision
);


--
-- Name: COLUMN aktivitas_perkuliahan_mahasiswa.id_status_mahasiswa; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.aktivitas_perkuliahan_mahasiswa.id_status_mahasiswa IS 'ID Status Mahasiswa. Web Service: GetStatusMahasiswa';


--
-- Name: biodata_mahasiswa; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.biodata_mahasiswa (
    id_mahasiswa uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    nama_mahasiswa character varying,
    jenis_kelamin character(1),
    tempat_lahir character varying(32),
    tanggal_lahir date,
    id_agama smallint,
    nama_agama character varying(50),
    nik character(16) DEFAULT '1234567891234567'::bigint NOT NULL,
    nisn character varying(10),
    npwp character varying(15),
    id_negara character(2),
    kewarganegaraan character varying DEFAULT 'ID'::bpchar NOT NULL,
    jalan character varying(80),
    dusun character varying(80),
    rt numeric(2,0),
    rw numeric(2,0),
    kelurahan character varying(60),
    kode_pos numeric(5,0),
    id_wilayah character(6) DEFAULT 0 NOT NULL,
    nama_jenis_tinggal character varying,
    id_alat_transportasi numeric(2,0),
    nama_alat_transportasi character varying,
    telepon character varying(20),
    handphone character varying(20),
    email character varying(60),
    penerima_kps numeric(1,0) DEFAULT 0,
    nik_ayah character varying(16),
    nama_ayah character varying(100),
    tanggal_lahir_ayah date,
    id_pendidikan_ayah numeric(2,0),
    nama_pendidikan_ayah character varying,
    id_pekerjaan_ayah integer,
    nama_pekerjaan_ayah character varying,
    id_penghasilan_ayah integer,
    nama_penghasilan_ayah character varying,
    nik_ibu character varying(16),
    nama_ibu_kandung character varying(100) NOT NULL,
    tanggal_lahir_ibu date,
    id_pendidikan_ibu numeric(2,0),
    nama_pendidikan_ibu character varying,
    id_pekerjaan_ibu integer,
    nama_pekerjaan_ibu character varying,
    id_penghasilan_ibu integer,
    nama_penghasilan_ibu character varying,
    nama_wali character varying(100),
    tanggal_lahir_wali date,
    id_pekerjaan_wali integer,
    nama_pekerjaan_wali character varying,
    id_penghasilan_wali integer,
    nama_penghasilan_wali character varying,
    id_kebutuhan_khusus_mahasiswa integer DEFAULT 0,
    nama_kebutuhan_khusus_mahasiswa character varying,
    id_kebutuhan_khusus_ayah integer DEFAULT 0,
    nama_kebutuhan_khusus_ayah character varying,
    id_kebutuhan_khusus_ibu integer DEFAULT 0,
    nama_kebutuhan_khusus_ibu character varying,
    id_jenis_tinggal smallint,
    id_pendidikan_wali numeric,
    nama_pendidikan_wali character varying,
    nama_wilayah character varying
);


--
-- Name: TABLE biodata_mahasiswa; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.biodata_mahasiswa IS 'master biodata mahasiswa';


--
-- Name: COLUMN biodata_mahasiswa.id_mahasiswa; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.id_mahasiswa IS 'Primary Key, kosongkan ketika mode Tambah';


--
-- Name: COLUMN biodata_mahasiswa.nama_mahasiswa; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.nama_mahasiswa IS 'Nama Mahasiswa';


--
-- Name: COLUMN biodata_mahasiswa.jenis_kelamin; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.jenis_kelamin IS 'L: Laki-laki, P: Perempuan, *: Belum ada informasi';


--
-- Name: COLUMN biodata_mahasiswa.tempat_lahir; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.tempat_lahir IS 'Tempat Lahir';


--
-- Name: COLUMN biodata_mahasiswa.tanggal_lahir; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.tanggal_lahir IS 'Tanggal Lahir';


--
-- Name: COLUMN biodata_mahasiswa.id_agama; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.id_agama IS 'Web Service feeder:  GetAgama';


--
-- Name: COLUMN biodata_mahasiswa.nama_agama; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.nama_agama IS 'Detail Agama';


--
-- Name: COLUMN biodata_mahasiswa.nik; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.nik IS 'Nomor Induk Kependudukan, wajib di isi';


--
-- Name: COLUMN biodata_mahasiswa.nisn; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.nisn IS 'Nomor Induk Siswa Nasional';


--
-- Name: COLUMN biodata_mahasiswa.npwp; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.npwp IS 'Nomor Pokok Wajib Pajak';


--
-- Name: COLUMN biodata_mahasiswa.id_negara; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.id_negara IS 'Web Service feeder: GetNegara';


--
-- Name: COLUMN biodata_mahasiswa.kewarganegaraan; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.kewarganegaraan IS 'detail Web Service: GetNegara';


--
-- Name: COLUMN biodata_mahasiswa.jalan; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.jalan IS 'Alamat jalan';


--
-- Name: COLUMN biodata_mahasiswa.dusun; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.dusun IS 'Dusun Desa';


--
-- Name: COLUMN biodata_mahasiswa.kelurahan; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.kelurahan IS 'kelurahan';


--
-- Name: COLUMN biodata_mahasiswa.kode_pos; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.kode_pos IS 'kode_pos harus 5 digit';


--
-- Name: COLUMN biodata_mahasiswa.id_wilayah; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.id_wilayah IS 'ID Wilayah. Web Service: GetWilayah';


--
-- Name: COLUMN biodata_mahasiswa.id_alat_transportasi; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.id_alat_transportasi IS 'Web Service: GetAlatTransportasi';


--
-- Name: COLUMN biodata_mahasiswa.nama_alat_transportasi; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.nama_alat_transportasi IS 'Detail alat tranportasi';


--
-- Name: COLUMN biodata_mahasiswa.penerima_kps; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.penerima_kps IS '0: Bukan penerima KPS, 1: Penerima KPS';


--
-- Name: COLUMN biodata_mahasiswa.nik_ayah; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.nik_ayah IS 'Nomor Induk Kependudukan, wajib di isi';


--
-- Name: COLUMN biodata_mahasiswa.nama_ayah; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.nama_ayah IS 'character varying(100)';


--
-- Name: COLUMN biodata_mahasiswa.id_pendidikan_ayah; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.id_pendidikan_ayah IS 'Web Service: GetJenjangPendidikan';


--
-- Name: COLUMN biodata_mahasiswa.nama_pendidikan_ayah; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.nama_pendidikan_ayah IS 'detail Web Service: GetJenjangPendidikan';


--
-- Name: COLUMN biodata_mahasiswa.id_pekerjaan_ayah; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.id_pekerjaan_ayah IS 'Web Service: GetPekerjaan';


--
-- Name: COLUMN biodata_mahasiswa.nama_pekerjaan_ayah; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.nama_pekerjaan_ayah IS 'detail Web Service: GetPekerjaan';


--
-- Name: COLUMN biodata_mahasiswa.id_penghasilan_ayah; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.id_penghasilan_ayah IS 'Web Service: GetPenghasilan';


--
-- Name: COLUMN biodata_mahasiswa.nama_penghasilan_ayah; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.nama_penghasilan_ayah IS 'detail Web Service: GetPenghasilan';


--
-- Name: COLUMN biodata_mahasiswa.nik_ibu; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.nik_ibu IS 'Nomor Induk Kependudukan, wajib di isi';


--
-- Name: COLUMN biodata_mahasiswa.nama_ibu_kandung; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.nama_ibu_kandung IS 'character varying(100)';


--
-- Name: COLUMN biodata_mahasiswa.id_pendidikan_ibu; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.id_pendidikan_ibu IS 'Web Service: GetJenjangPendidikan';


--
-- Name: COLUMN biodata_mahasiswa.nama_pendidikan_ibu; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.nama_pendidikan_ibu IS 'detail Web Service: GetJenjangPendidikan';


--
-- Name: COLUMN biodata_mahasiswa.id_pekerjaan_ibu; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.id_pekerjaan_ibu IS 'Web Service: GetPekerjaan';


--
-- Name: COLUMN biodata_mahasiswa.nama_pekerjaan_ibu; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.nama_pekerjaan_ibu IS 'detail Web Service: GetPekerjaan';


--
-- Name: COLUMN biodata_mahasiswa.id_penghasilan_ibu; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.id_penghasilan_ibu IS 'Web Service: GetPenghasilan';


--
-- Name: COLUMN biodata_mahasiswa.nama_penghasilan_ibu; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.nama_penghasilan_ibu IS 'detail Web Service: GetPenghasilan';


--
-- Name: COLUMN biodata_mahasiswa.id_pekerjaan_wali; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.id_pekerjaan_wali IS 'Web Service: GetPekerjaan';


--
-- Name: COLUMN biodata_mahasiswa.nama_pekerjaan_wali; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.nama_pekerjaan_wali IS 'detail Web Service: GetPekerjaan';


--
-- Name: COLUMN biodata_mahasiswa.id_penghasilan_wali; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.id_penghasilan_wali IS 'Web Service: GetPenghasilan';


--
-- Name: COLUMN biodata_mahasiswa.nama_penghasilan_wali; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.biodata_mahasiswa.nama_penghasilan_wali IS 'detail Web Service: GetPenghasilan';


--
-- Name: kurikulum; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.kurikulum (
    id_kurikulum uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    nama_kurikulum character varying(60),
    id_prodi uuid,
    id_semester character(5),
    jumlah_sks_lulus numeric(3,0),
    jumlah_sks_wajib numeric(3,0),
    jumlah_sks_pilihan numeric(3,0),
    id_tahun_akademik uuid,
    nama_program_studi character varying(100)
);


--
-- Name: TABLE kurikulum; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.kurikulum IS 'Kurikulum';


--
-- Name: COLUMN kurikulum.nama_kurikulum; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.kurikulum.nama_kurikulum IS 'Nama Kuriukulum';


--
-- Name: COLUMN kurikulum.id_prodi; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.kurikulum.id_prodi IS 'ID Prodi. Web Service: GetProdi';


--
-- Name: COLUMN kurikulum.id_semester; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.kurikulum.id_semester IS 'id Semester berlaku\nID Semester. Web Service: GetSemester';


--
-- Name: list_mahasiswa; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.list_mahasiswa (
    id_registrasi_mahasiswa uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    id_mahasiswa uuid NOT NULL,
    nama_mahasiswa character(100),
    jenis_kelamin character(1),
    tanggal_lahir date,
    id_perguruan_tinggi character varying,
    id_agama smallint,
    nama_agama character varying(50),
    id_prodi uuid,
    nama_program_studi character varying,
    id_status_mahasiswa character(1) DEFAULT 'A'::bpchar,
    nama_status_mahasiswa character varying,
    nim character varying(24),
    id_periode_masuk character(5),
    nama_periode_masuk character varying,
    id_jenis_daftar numeric(2,0),
    id_jalur_daftar numeric(4,0),
    id_bidang_minat uuid,
    sks_diakui numeric(3,0),
    id_perguruan_tinggi_asal uuid,
    id_prodi_asal uuid,
    id_pembiayaan smallint,
    biaya_masuk numeric(16,2),
    tgl_keluar date,
    no_ijazah character varying,
    no_sk character varying,
    jenis_keluar character varying,
    periode_keluar character(5),
    tgl_sk date,
    ipk_lulus numeric(8,2),
    id_tahun_akademik uuid,
    tanggal_daftar date,
    kode_pt character(6),
    nama_perguruan_tinggi_asal character varying,
    nama_prodi_asal character varying,
    nama_lembaga_prodi_asal character varying
);


--
-- Name: TABLE list_mahasiswa; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.list_mahasiswa IS 'detail mahasiswa program studi';


--
-- Name: COLUMN list_mahasiswa.id_registrasi_mahasiswa; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.id_registrasi_mahasiswa IS 'primary';


--
-- Name: COLUMN list_mahasiswa.id_mahasiswa; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.id_mahasiswa IS 'FK dari Biodata_mahasiswa';


--
-- Name: COLUMN list_mahasiswa.nama_mahasiswa; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.nama_mahasiswa IS 'detail mahasiswa ( jangan query menampilkan nama disini - hanya field bantu)';


--
-- Name: COLUMN list_mahasiswa.jenis_kelamin; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.jenis_kelamin IS 'detail mahasiswa ( jangan query menampilkan nama disini - hanya field bantu)\nL: Laki-laki, P: Perempuan, *: Belum ada informasi';


--
-- Name: COLUMN list_mahasiswa.tanggal_lahir; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.tanggal_lahir IS 'detail mahasiswa ( jangan query menampilkan nama disini - hanya field bantu)';


--
-- Name: COLUMN list_mahasiswa.id_perguruan_tinggi; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.id_perguruan_tinggi IS 'ID Perguruan Tinggi. Web Service: GetProfilPT';


--
-- Name: COLUMN list_mahasiswa.id_agama; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.id_agama IS 'detail mahasiswa ( jangan query menampilkan nama disini - hanya field bantu)\nWeb Service: GetAgama';


--
-- Name: COLUMN list_mahasiswa.nama_agama; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.nama_agama IS 'detail mahasiswa ( jangan query menampilkan nama disini - hanya field bantu)';


--
-- Name: COLUMN list_mahasiswa.id_prodi; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.id_prodi IS 'ID Prodi. Web Service: GetProdi';


--
-- Name: COLUMN list_mahasiswa.nama_program_studi; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.nama_program_studi IS 'detail ID Prodi. Web Service: GetProdi';


--
-- Name: COLUMN list_mahasiswa.nim; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.nim IS 'Nomor Induk Mahasiswa';


--
-- Name: COLUMN list_mahasiswa.id_periode_masuk; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.id_periode_masuk IS 'ID periode Masuk';


--
-- Name: COLUMN list_mahasiswa.nama_periode_masuk; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.nama_periode_masuk IS 'Tahun Akademik';


--
-- Name: COLUMN list_mahasiswa.id_jenis_daftar; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.id_jenis_daftar IS 'Web Service: GetJenisPendaftaran';


--
-- Name: COLUMN list_mahasiswa.id_jalur_daftar; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.id_jalur_daftar IS 'Web Service: GetJalurMasuk';


--
-- Name: COLUMN list_mahasiswa.id_bidang_minat; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.id_bidang_minat IS 'ID Bidang Minat. Web Service: GetListBidangMinat';


--
-- Name: COLUMN list_mahasiswa.sks_diakui; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.sks_diakui IS 'Jika Pindahan';


--
-- Name: COLUMN list_mahasiswa.id_perguruan_tinggi_asal; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.id_perguruan_tinggi_asal IS 'Jika Pindahan \nID Perguruan Tinggi. Web Service: GetAllPT';


--
-- Name: COLUMN list_mahasiswa.id_prodi_asal; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.id_prodi_asal IS 'Jika Pindahan\nID Prodi. Web Service: GetAllProdi';


--
-- Name: COLUMN list_mahasiswa.id_pembiayaan; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.id_pembiayaan IS 'ID Pembiayaan Awal. Web Service: GetPembiayaan';


--
-- Name: COLUMN list_mahasiswa.biaya_masuk; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.biaya_masuk IS 'Biaya DPI';


--
-- Name: COLUMN list_mahasiswa.jenis_keluar; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.jenis_keluar IS 'lulus,do,pindah,wafat,mengundurkan diri';


--
-- Name: COLUMN list_mahasiswa.periode_keluar; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.periode_keluar IS 'id semester';


--
-- Name: COLUMN list_mahasiswa.id_tahun_akademik; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.list_mahasiswa.id_tahun_akademik IS 'dari master tahun akademik';


--
-- Name: lokasi_perkuliahan; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.lokasi_perkuliahan (
    id_lokasi_perkuliahan uuid NOT NULL,
    nama_lokasi_perkuliahan character varying NOT NULL,
    no_telp character varying,
    alamat character varying,
    jenis_lokasi character varying,
    pimpinan character varying,
    id_prodi uuid,
    nama_program_studi character varying,
    status character(1) DEFAULT 1
);


--
-- Name: COLUMN lokasi_perkuliahan.status; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.lokasi_perkuliahan.status IS '0 = tidak aktif\n1 = aktif';


--
-- Name: mahasiswa_angkatan; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.mahasiswa_angkatan (
    id_mahasiswa_angkatan uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    id_registrasi_mahasiswa uuid,
    tgl_insert timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    id_angkatan_mahasiswa uuid
);


--
-- Name: mahasiswa_krs; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.mahasiswa_krs (
    id_mahasiswa_krs uuid NOT NULL,
    id_registrasi_mahasiswa uuid[] NOT NULL,
    id_mahasiswa uuid,
    id_prodi uuid NOT NULL,
    id_matakuliah_krs_ditawarkan uuid NOT NULL,
    nilai_angka numeric(4,2),
    nilai_indeks numeric(2,2),
    nilai_huruf character varying(2),
    status_krs character(1),
    approval character(1) DEFAULT 0,
    tgl_insert timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    validasi character(1) DEFAULT 0
);


--
-- Name: COLUMN mahasiswa_krs.nilai_angka; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.mahasiswa_krs.nilai_angka IS 'Niai angka dari olah nilai';


--
-- Name: COLUMN mahasiswa_krs.nilai_indeks; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.mahasiswa_krs.nilai_indeks IS 'nilai indeks \nA = 4\nAB = 3.5\nB = 3\nBC  2.5\nC = 2\nCD = 1.5\nD = 1\nE = 0';


--
-- Name: COLUMN mahasiswa_krs.nilai_huruf; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.mahasiswa_krs.nilai_huruf IS 'A \nAB \nB \nBC \nC\nCD \nD';


--
-- Name: COLUMN mahasiswa_krs.status_krs; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.mahasiswa_krs.status_krs IS '1 : KRS \n2: Batal Tambah';


--
-- Name: COLUMN mahasiswa_krs.approval; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.mahasiswa_krs.approval IS '0 = tunggu\n1 = disetujui';


--
-- Name: COLUMN mahasiswa_krs.validasi; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.mahasiswa_krs.validasi IS '1 = valid\n0 = belum validasi';


--
-- Name: mahasiswa_kurikulum; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.mahasiswa_kurikulum (
    id_mahasiswa_kurikulum uuid NOT NULL,
    id_kurikulum uuid,
    nama_kurikulum character varying(60),
    id_mahasiswa uuid,
    nama_mahasiswa character(100),
    nim character varying(24),
    id_semester character(5),
    id_registrasi_mahasiswa uuid[],
    id_prodi uuid
);


--
-- Name: TABLE mahasiswa_kurikulum; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.mahasiswa_kurikulum IS 'Mahasiswa Kurikulum';


--
-- Name: mahasiswa_remidi; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.mahasiswa_remidi (
    id_mahasiswa_remidi uuid NOT NULL,
    id_registrasi_mahasiswa uuid[] NOT NULL,
    id_mahasiswa uuid,
    id_prodi uuid NOT NULL,
    id_matakuliah_remidi_ditawarkan uuid NOT NULL,
    nilai_angka numeric(4,2),
    approval character(1) DEFAULT 0,
    tgl_insert timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    validasi character(1) DEFAULT 0
);


--
-- Name: COLUMN mahasiswa_remidi.nilai_angka; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.mahasiswa_remidi.nilai_angka IS 'Niai angka dari olah nilai';


--
-- Name: COLUMN mahasiswa_remidi.approval; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.mahasiswa_remidi.approval IS '0 = tunggu\n1 = disetujui';


--
-- Name: COLUMN mahasiswa_remidi.validasi; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.mahasiswa_remidi.validasi IS '1 = valid\n0 = belum validasi';


--
-- Name: mahasiswa_rencana_remidi; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.mahasiswa_rencana_remidi (
    id_mahasiswa_krs uuid NOT NULL,
    id_registrasi_mahasiswa uuid[] NOT NULL,
    id_mahasiswa uuid,
    id_prodi uuid NOT NULL,
    id_matakuliah_rencana_remidi_ditawarkan uuid NOT NULL,
    nilai_angka numeric(4,2),
    nilai_indeks numeric(2,2),
    nilai_huruf character varying(2),
    status_krs character(1),
    approval character(1) DEFAULT 0,
    tgl_insert timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    validasi character(1) DEFAULT 0
);


--
-- Name: COLUMN mahasiswa_rencana_remidi.nilai_angka; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.mahasiswa_rencana_remidi.nilai_angka IS 'Niai angka dari olah nilai';


--
-- Name: COLUMN mahasiswa_rencana_remidi.nilai_indeks; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.mahasiswa_rencana_remidi.nilai_indeks IS 'nilai indeks \nA = 4\nAB = 3.5\nB = 3\nBC  2.5\nC = 2\nCD = 1.5\nD = 1\nE = 0';


--
-- Name: COLUMN mahasiswa_rencana_remidi.nilai_huruf; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.mahasiswa_rencana_remidi.nilai_huruf IS 'A \nAB \nB \nBC \nC\nCD \nD';


--
-- Name: COLUMN mahasiswa_rencana_remidi.status_krs; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.mahasiswa_rencana_remidi.status_krs IS '1 : KRS \n2: Batal Tambah';


--
-- Name: COLUMN mahasiswa_rencana_remidi.approval; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.mahasiswa_rencana_remidi.approval IS '0 = tunggu\n1 = disetujui';


--
-- Name: COLUMN mahasiswa_rencana_remidi.validasi; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.mahasiswa_rencana_remidi.validasi IS '1 = valid\n0 = belum validasi';


--
-- Name: master_agama; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.master_agama (
    id_agama smallint NOT NULL,
    nama_agama character varying(50) NOT NULL
);


--
-- Name: TABLE master_agama; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.master_agama IS 'GetAgama\n\n{\n            "id_agama": 2,\n            "nama_agama": "Kristen"\n        },\n        {\n            "id_agama": 5,\n            "nama_agama": "Budha"\n        },\n        {\n            "id_agama": 4,\n            "nama_agama": "Hindu"\n        },\n        {\n            "id_agama": 1,\n            "nama_agama": "Islam"\n        },\n        {\n            "id_agama": 99,\n            "nama_agama": "Lainnya"\n        },\n        {\n            "id_agama": 3,\n            "nama_agama": "Katolik"\n        },\n        {\n            "id_agama": 6,\n            "nama_agama": "Khonghucu"\n        }';


--
-- Name: master_alat_transportasi; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.master_alat_transportasi (
    id_alat_transportasi smallint NOT NULL,
    nama_alat_transportasi character varying(100)
);


--
-- Name: TABLE master_alat_transportasi; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.master_alat_transportasi IS 'GetAlatTransportasi\n{\n            "id_alat_transportasi": "11",\n            "nama_alat_transportasi": "Kuda"\n        },\n        {\n            "id_alat_transportasi": "4",\n            "nama_alat_transportasi": "Mobil/bus antar jemput"\n        },\n        {\n            "id_alat_transportasi": "8",\n            "nama_alat_transportasi": "Perahu penyeberangan/rakit/getek"\n        },\n        {\n            "id_alat_transportasi": "13",\n            "nama_alat_transportasi": "Sepeda motor"\n        },\n        {\n            "id_alat_transportasi": "1",\n            "nama_alat_transportasi": "Jalan kaki"\n        },\n        {\n            "id_alat_transportasi": "99",\n            "nama_alat_transportasi": "Lainnya"\n        },\n        {\n            "id_alat_transportasi": "14",\n            "nama_alat_transportasi": "Mobil pribadi"\n        },\n        {\n            "id_alat_transportasi": "6",\n            "nama_alat_transportasi": "Ojek"\n        },\n        {\n            "id_alat_transportasi": "5",\n            "nama_alat_transportasi": "Kereta api"\n        },\n        {\n            "id_alat_transportasi": "12",\n            "nama_alat_transportasi": "Sepeda"\n        },\n        {\n            "id_alat_transportasi": "3",\n            "nama_alat_transportasi": "Angkutan umum/bus/pete-pete"\n        },\n        {\n            "id_alat_transportasi": "7",\n            "nama_alat_transportasi": "Andong/bendi/sado/dokar/delman/becak"\n        }';


--
-- Name: master_angkatan_mahasiswa; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.master_angkatan_mahasiswa (
    id_angkatan_mahasiswa uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    nama_angkatan_mahasiswa character varying(100),
    id_kurikulum uuid,
    id_tahun_akademik uuid,
    id_semester character(5),
    id_prodi uuid,
    nama_program_studi character varying(100)
);


--
-- Name: COLUMN master_angkatan_mahasiswa.nama_angkatan_mahasiswa; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_angkatan_mahasiswa.nama_angkatan_mahasiswa IS 'Nama ANgkatan Mahasiswa';


--
-- Name: COLUMN master_angkatan_mahasiswa.id_kurikulum; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_angkatan_mahasiswa.id_kurikulum IS 'dari tabel kurikulum';


--
-- Name: master_jalur_masuk; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.master_jalur_masuk (
    id_jalur_masuk smallint NOT NULL,
    nama_jalur_masuk character varying(50) NOT NULL
);


--
-- Name: TABLE master_jalur_masuk; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.master_jalur_masuk IS 'GetJalurMasuk\n{\n            "id_jalur_masuk": "11",\n            "nama_jalur_masuk": "Program Kerjasama Perusahaan/Institusi/Pemerintah"\n        },\n        {\n            "id_jalur_masuk": "4",\n            "nama_jalur_masuk": "Prestasi"\n        },\n        {\n            "id_jalur_masuk": "3",\n            "nama_jalur_masuk": "Penelusuran Minat dan Kemampuan (PMDK)"\n        },\n        {\n            "id_jalur_masuk": "12",\n            "nama_jalur_masuk": "Seleksi Mandiri"\n        },\n        {\n            "id_jalur_masuk": "13",\n            "nama_jalur_masuk": "Ujian Masuk Bersama Lainnya"\n        },\n        {\n            "id_jalur_masuk": "14",\n            "nama_jalur_masuk": "Seleksi Nasional Berdasarkan Tes (SNBT)"\n        },\n        {\n            "id_jalur_masuk": "15",\n            "nama_jalur_masuk": "Seleksi Nasional Berdasarkan Prestasi (SNBP)"\n        },\n        {\n            "id_jalur_masuk": "9",\n            "nama_jalur_masuk": "Program Internasional"\n        }';


--
-- Name: master_jenis_keluar; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.master_jenis_keluar (
    id_jenis_keluar smallint NOT NULL,
    jenis_keluar character varying(50) NOT NULL
);


--
-- Name: TABLE master_jenis_keluar; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.master_jenis_keluar IS 'GetJenisKeluar\n{\n            "id_jenis_keluar": "5",\n            "jenis_keluar": "Putus Studi",\n            "apa_mahasiswa": "1"\n        },\n        {\n            "id_jenis_keluar": "3",\n            "jenis_keluar": "Dikeluarkan",\n            "apa_mahasiswa": "1"\n        },\n        {\n            "id_jenis_keluar": "9",\n            "jenis_keluar": "Pensiun",\n            "apa_mahasiswa": "0"\n        },\n        {\n            "id_jenis_keluar": "2",\n            "jenis_keluar": "Mutasi",\n            "apa_mahasiswa": "1"\n        },\n        {\n            "id_jenis_keluar": "4",\n            "jenis_keluar": "Mengundurkan diri",\n            "apa_mahasiswa": "1"\n        },\n        {\n            "id_jenis_keluar": "1",\n            "jenis_keluar": "Lulus",\n            "apa_mahasiswa": "1"\n        },\n        {\n            "id_jenis_keluar": "0",\n            "jenis_keluar": "Selesai Pendidikan Non Gelar",\n            "apa_mahasiswa": "1"\n        },\n        {\n            "id_jenis_keluar": "6",\n            "jenis_keluar": "Wafat",\n            "apa_mahasiswa": "1"\n        },\n        {\n            "id_jenis_keluar": "8",\n            "jenis_keluar": "Alih Fungsi",\n            "apa_mahasiswa": "0"\n        }';


--
-- Name: master_jenis_matakuliah; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.master_jenis_matakuliah (
    id_jenis_mata_kuliah character(1) NOT NULL,
    nama_jenis_mata_kuliah character varying(100)
);


--
-- Name: master_jenis_perndaftaran; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.master_jenis_perndaftaran (
    id_jenis_daftar smallint NOT NULL,
    nama_jenis_daftar character varying(50) NOT NULL,
    untuk_daftar_sekolah integer
);


--
-- Name: TABLE master_jenis_perndaftaran; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.master_jenis_perndaftaran IS '{\n            "id_jenis_daftar": "13",\n            "nama_jenis_daftar": "RPL Perolehan SKS",\n            "untuk_daftar_sekolah": "1"\n        },\n        {\n            "id_jenis_daftar": "14",\n            "nama_jenis_daftar": "Pendidikan Non Gelar (Course)",\n            "untuk_daftar_sekolah": "1"\n        },\n        {\n            "id_jenis_daftar": "15",\n            "nama_jenis_daftar": "Fast Track",\n            "untuk_daftar_sekolah": "1"\n        },\n        {\n            "id_jenis_daftar": "16",\n            "nama_jenis_daftar": "RPL Transfer SKS",\n            "untuk_daftar_sekolah": "1"\n        },\n        {\n            "id_jenis_daftar": "5",\n            "nama_jenis_daftar": "Mengulang",\n            "untuk_daftar_sekolah": "0"\n        },\n        {\n            "id_jenis_daftar": "3",\n            "nama_jenis_daftar": "Naik kelas",\n            "untuk_daftar_sekolah": "0"\n        },\n        {\n            "id_jenis_daftar": "1",\n            "nama_jenis_daftar": "Peserta didik baru",\n            "untuk_daftar_sekolah": "1"\n        },\n        {\n            "id_jenis_daftar": "8",\n            "nama_jenis_daftar": "Pindahan Alih Bentuk",\n            "untuk_daftar_sekolah": "0"\n        },\n        {\n            "id_jenis_daftar": "6",\n            "nama_jenis_daftar": "Lanjutan semester",\n            "untuk_daftar_sekolah": "0"\n        },\n        {\n            "id_jenis_daftar": "2",\n            "nama_jenis_daftar": "Pindahan",\n            "untuk_daftar_sekolah": "1"\n        },\n        {\n            "id_jenis_daftar": "4",\n            "nama_jenis_daftar": "Akselerasi",\n            "untuk_daftar_sekolah": "0"\n        }';


--
-- Name: master_jenis_prestasi; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.master_jenis_prestasi (
    id_jenis_prestasi smallint NOT NULL,
    nama_jenis_prestasi character varying(50)
);


--
-- Name: TABLE master_jenis_prestasi; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.master_jenis_prestasi IS 'GetJenisPrestasi\n {\n            "id_jenis_prestasi": 3,\n            "nama_jenis_prestasi": "Olahraga"\n        },\n        {\n            "id_jenis_prestasi": 2,\n            "nama_jenis_prestasi": "Seni"\n        },\n        {\n            "id_jenis_prestasi": 1,\n            "nama_jenis_prestasi": "Sains"\n        },\n        {\n            "id_jenis_prestasi": 9,\n            "nama_jenis_prestasi": "Lain-lain"\n        }';


--
-- Name: master_jenis_tinggal; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.master_jenis_tinggal (
    id_jenis_tinggal smallint NOT NULL,
    nama_jenis_tinggal character varying(50) NOT NULL
);


--
-- Name: TABLE master_jenis_tinggal; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.master_jenis_tinggal IS 'GetJenisTinggal\n{\n            "id_jenis_tinggal": "10",\n            "nama_jenis_tinggal": "Rumah sendiri"\n        },\n        {\n            "id_jenis_tinggal": "4",\n            "nama_jenis_tinggal": "Asrama"\n        },\n        {\n            "id_jenis_tinggal": "5",\n            "nama_jenis_tinggal": "Panti asuhan"\n        },\n        {\n            "id_jenis_tinggal": "1",\n            "nama_jenis_tinggal": "Bersama orang tua"\n        },\n        {\n            "id_jenis_tinggal": "3",\n            "nama_jenis_tinggal": "Kost"\n        },\n        {\n            "id_jenis_tinggal": "2",\n            "nama_jenis_tinggal": "Wali"\n        },\n        {\n            "id_jenis_tinggal": "99",\n            "nama_jenis_tinggal": "Lainnya"\n        }';


--
-- Name: master_jenjang_pendidikan; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.master_jenjang_pendidikan (
    id_jenjang_didik smallint NOT NULL,
    nama_jenjang_didik character varying(50) NOT NULL
);


--
-- Name: TABLE master_jenjang_pendidikan; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.master_jenjang_pendidikan IS 'GetJenjangPendidikan\n {\n            "id_jenjang_didik": "8",\n            "nama_jenjang_didik": "Paket B"\n        },\n        {\n            "id_jenjang_didik": "37",\n            "nama_jenjang_didik": "Sp-2"\n        },\n        {\n            "id_jenjang_didik": "9",\n            "nama_jenjang_didik": "Paket C"\n        },\n        {\n            "id_jenjang_didik": "30",\n            "nama_jenjang_didik": "S1"\n        },\n        {\n            "id_jenjang_didik": "0",\n            "nama_jenjang_didik": "Tidak sekolah"\n        },\n        {\n            "id_jenjang_didik": "5",\n            "nama_jenjang_didik": "SMP / sederajat"\n        },\n        {\n            "id_jenjang_didik": "3",\n            "nama_jenjang_didik": "Putus SD"\n        },\n        {\n            "id_jenjang_didik": "35",\n            "nama_jenjang_didik": "S2"\n        },\n        {\n            "id_jenjang_didik": "32",\n            "nama_jenjang_didik": "Sp-1"\n        },\n        {\n            "id_jenjang_didik": "1",\n            "nama_jenjang_didik": "PAUD"\n        },\n        {\n            "id_jenjang_didik": "20",\n            "nama_jenjang_didik": "D1"\n        },\n        {\n            "id_jenjang_didik": "4",\n            "nama_jenjang_didik": "SD / sederajat"\n        },\n        {\n            "id_jenjang_didik": "91",\n            "nama_jenjang_didik": "Informal"\n        },\n        {\n            "id_jenjang_didik": "31",\n            "nama_jenjang_didik": "Profesi"\n        },\n        {\n            "id_jenjang_didik": "36",\n            "nama_jenjang_didik": "S2 Terapan"\n        },\n        {\n            "id_jenjang_didik": "41",\n            "nama_jenjang_didik": "S3 Terapan"\n        },\n        {\n            "id_jenjang_didik": "6",\n            "nama_jenjang_didik": "SMA / sederajat"\n        },\n        {\n            "id_jenjang_didik": "40",\n            "nama_jenjang_didik": "S3"\n        },\n        {\n            "id_jenjang_didik": "2",\n            "nama_jenjang_didik": "TK / sederajat"\n        },\n        {\n            "id_jenjang_didik": "90",\n            "nama_jenjang_didik": "Non formal"\n        },\n        {\n            "id_jenjang_didik": "7",\n            "nama_jenjang_didik": "Paket A"\n        },\n        {\n            "id_jenjang_didik": "23",\n            "nama_jenjang_didik": "D4"\n        },\n        {\n            "id_jenjang_didik": "22",\n            "nama_jenjang_didik": "D3"\n        },\n        {\n            "id_jenjang_didik": "21",\n            "nama_jenjang_didik": "D2"\n        },\n        {\n            "id_jenjang_didik": "99",\n            "nama_jenjang_didik": "Lainnya"\n        }';


--
-- Name: master_kegiatan_perkuliahan; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.master_kegiatan_perkuliahan (
    id_master_kegiatan_perkuliahan uuid NOT NULL,
    nama_kegiatan_perkuliahan uuid NOT NULL,
    status_data character(1) DEFAULT 1
);


--
-- Name: COLUMN master_kegiatan_perkuliahan.status_data; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_kegiatan_perkuliahan.status_data IS '0 = tidak aktif\n1 = aktif';


--
-- Name: master_kelas_mahasiswa; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.master_kelas_mahasiswa (
    id_master_kelas_mahasiswa uuid NOT NULL,
    nama_kelas character varying(250) NOT NULL,
    id_prodi uuid NOT NULL,
    id_semester character(5) NOT NULL,
    nama_program_studi character varying
);


--
-- Name: TABLE master_kelas_mahasiswa; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.master_kelas_mahasiswa IS 'master kelompok SGD untuk memasukan kelas yang berbeda kurikulum atau kode matakuliah';


--
-- Name: COLUMN master_kelas_mahasiswa.nama_program_studi; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_kelas_mahasiswa.nama_program_studi IS 'nama program studi';


--
-- Name: master_kode_pembayaran; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.master_kode_pembayaran (
    id_kode_pembayaran uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    kode_rekening character varying(6),
    nama_rekening character varying,
    id_prodi uuid,
    status boolean DEFAULT true,
    nama_program_studi character varying(100)
);


--
-- Name: COLUMN master_kode_pembayaran.id_kode_pembayaran; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_kode_pembayaran.id_kode_pembayaran IS 'id kode pembayaran';


--
-- Name: COLUMN master_kode_pembayaran.status; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_kode_pembayaran.status IS '0 tidak aktif\n1 aktif';


--
-- Name: master_matakuliah; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.master_matakuliah (
    id_matkul uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    kode_mata_kuliah character varying(20) NOT NULL,
    nama_mata_kuliah character varying(200) NOT NULL,
    id_prodi uuid NOT NULL,
    nama_program_studi character varying,
    id_jenis_mata_kuliah character(1),
    id_kelompok_mata_kuliah character(1),
    sks_mata_kuliah numeric(5,0) DEFAULT 0 NOT NULL,
    sks_tatap_muka numeric(5,0) DEFAULT 0 NOT NULL,
    sks_praktek numeric(5,0) DEFAULT 0 NOT NULL,
    sks_praktek_lapangan numeric(5,0) DEFAULT 0 NOT NULL,
    sks_simulasi numeric(5,0) DEFAULT 0 NOT NULL,
    metode_kuliah character(50),
    ada_sap numeric(1,0),
    ada_silabus numeric(1,0),
    ada_bahan_ajar numeric(1,0),
    ada_acara_praktek numeric(1,0),
    ada_diktat numeric(1,0),
    tanggal_mulai_efektif date,
    tanggal_akhir_efektif date
);


--
-- Name: TABLE master_matakuliah; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.master_matakuliah IS 'master matakuliah';


--
-- Name: COLUMN master_matakuliah.id_matkul; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_matakuliah.id_matkul IS 'Primary Key, kosongkan ketika mode Tambah';


--
-- Name: COLUMN master_matakuliah.kode_mata_kuliah; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_matakuliah.kode_mata_kuliah IS 'Kode Matakuliah';


--
-- Name: COLUMN master_matakuliah.nama_mata_kuliah; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_matakuliah.nama_mata_kuliah IS 'Nama Matakuliah';


--
-- Name: COLUMN master_matakuliah.id_prodi; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_matakuliah.id_prodi IS 'ID Prodi. Web Service: GetProdi';


--
-- Name: COLUMN master_matakuliah.nama_program_studi; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_matakuliah.nama_program_studi IS 'detail ID Prodi. Web Service: GetProdi';


--
-- Name: COLUMN master_matakuliah.id_jenis_mata_kuliah; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_matakuliah.id_jenis_mata_kuliah IS 'A=Wajib, B=Pilihan, C=Wajib Peminatan, D=Pilihan Peminatan, S=Tugas akhir/Skripsi/Tesis/Disertasi';


--
-- Name: COLUMN master_matakuliah.id_kelompok_mata_kuliah; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_matakuliah.id_kelompok_mata_kuliah IS 'A=MPK, B=MKK, C=MKB, D=MPB, E=MBB, F=MKU/MKDU, G=MKDK, H=MKK';


--
-- Name: COLUMN master_matakuliah.sks_mata_kuliah; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_matakuliah.sks_mata_kuliah IS 'SKS Total';


--
-- Name: COLUMN master_matakuliah.sks_tatap_muka; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_matakuliah.sks_tatap_muka IS 'SKS teori';


--
-- Name: COLUMN master_matakuliah.sks_praktek; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_matakuliah.sks_praktek IS 'SKS Praktikum';


--
-- Name: COLUMN master_matakuliah.sks_praktek_lapangan; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_matakuliah.sks_praktek_lapangan IS 'SKS Praktek Lapangan';


--
-- Name: COLUMN master_matakuliah.sks_simulasi; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_matakuliah.sks_simulasi IS 'SKS Simulasi';


--
-- Name: master_parameter_penilaian; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.master_parameter_penilaian (
    id_master_parameter_penilaian uuid NOT NULL,
    id_prodi uuid,
    nama_program_studi character varying,
    id_semester character(5),
    ">=a" numeric(8,2) NOT NULL,
    ">=ab" numeric(8,2) NOT NULL,
    ">=b" numeric(8,2) NOT NULL,
    ">=bc" numeric(8,2) NOT NULL,
    ">=c" numeric(8,2) NOT NULL,
    ">=cd" numeric(8,2) NOT NULL,
    ">=d" numeric(8,2) NOT NULL,
    id_matkul uuid NOT NULL,
    nama_mata_kuliah character varying(200),
    id_matakuliah_krs_ditawarkan uuid NOT NULL
);


--
-- Name: TABLE master_parameter_penilaian; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.master_parameter_penilaian IS 'parameter penilaian';


--
-- Name: master_pekerjaan; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.master_pekerjaan (
    id_pekerjaan smallint NOT NULL,
    nama_pekerjaan character varying(100)
);


--
-- Name: TABLE master_pekerjaan; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.master_pekerjaan IS 'GetPekerjaan\n {\n            "id_pekerjaan": 15,\n            "nama_pekerjaan": "Magang"\n        },\n        {\n            "id_pekerjaan": 16,\n            "nama_pekerjaan": "Tenaga Pengajar / Instruktur / Fasiltator"\n        },\n        {\n            "id_pekerjaan": 17,\n            "nama_pekerjaan": "Pimpinan / Manajerial"\n        },\n        {\n            "id_pekerjaan": 8,\n            "nama_pekerjaan": "Pedagang Besar"\n        },\n        {\n            "id_pekerjaan": 6,\n            "nama_pekerjaan": "Karyawan Swasta"\n        },\n        {\n            "id_pekerjaan": 11,\n            "nama_pekerjaan": "Buruh"\n        },\n        {\n            "id_pekerjaan": 10,\n            "nama_pekerjaan": "Wirausaha"\n        },\n        {\n            "id_pekerjaan": 5,\n            "nama_pekerjaan": "PNS/TNI/Polri"\n        },\n        {\n            "id_pekerjaan": 12,\n            "nama_pekerjaan": "Pensiunan"\n        },\n        {\n            "id_pekerjaan": 4,\n            "nama_pekerjaan": "Peternak"\n        },\n        {\n            "id_pekerjaan": 9,\n            "nama_pekerjaan": "Wiraswasta"\n        },\n        {\n            "id_pekerjaan": 99,\n            "nama_pekerjaan": "Lainnya"\n        },\n        {\n            "id_pekerjaan": 3,\n            "nama_pekerjaan": "Petani"\n        },\n        {\n            "id_pekerjaan": 98,\n            "nama_pekerjaan": "Sudah Meninggal"\n        },\n        {\n            "id_pekerjaan": 1,\n            "nama_pekerjaan": "Tidak bekerja"\n        },\n        {\n            "id_pekerjaan": 7,\n            "nama_pekerjaan": "Pedagang Kecil"\n        },\n        {\n            "id_pekerjaan": 2,\n            "nama_pekerjaan": "Nelayan"\n        },\n        {\n            "id_pekerjaan": 13,\n            "nama_pekerjaan": "Peneliti"\n        },\n        {\n            "id_pekerjaan": 14,\n            "nama_pekerjaan": "Tim Ahli / Konsultan"\n        }';


--
-- Name: master_pembiayaan_mahasiswa; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.master_pembiayaan_mahasiswa (
    id_pembiayaan smallint NOT NULL,
    nama_pembiayaan character varying(50)
);


--
-- Name: TABLE master_pembiayaan_mahasiswa; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.master_pembiayaan_mahasiswa IS 'GetPembiayaan \n{\n            "id_pembiayaan": "1",\n            "nama_pembiayaan": "Mandiri"\n        },\n        {\n            "id_pembiayaan": "2",\n            "nama_pembiayaan": "Beasiswa Tidak Penuh"\n        },\n        {\n            "id_pembiayaan": "3",\n            "nama_pembiayaan": "Beasiswa Penuh"\n        }';


--
-- Name: master_penghasilan; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.master_penghasilan (
    id_penghasilan smallint NOT NULL,
    nama_penghasilan character varying(100) NOT NULL
);


--
-- Name: TABLE master_penghasilan; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.master_penghasilan IS 'GetPenghasilan\n{\n            "id_penghasilan": 15,\n            "nama_penghasilan": "Rp. 5,000,000 - Rp. 20,000,000"\n        },\n        {\n            "id_penghasilan": 16,\n            "nama_penghasilan": "Lebih dari Rp. 20,000,000"\n        },\n        {\n            "id_penghasilan": 11,\n            "nama_penghasilan": "Kurang dari Rp. 500,000"\n        },\n        {\n            "id_penghasilan": 14,\n            "nama_penghasilan": "Rp. 2,000,000 - Rp. 4,999,999"\n        },\n        {\n            "id_penghasilan": 0,\n            "nama_penghasilan": ""\n        },\n        {\n            "id_penghasilan": 13,\n            "nama_penghasilan": "Rp. 1,000,000 - Rp. 1,999,999"\n        },\n        {\n            "id_penghasilan": 12,\n            "nama_penghasilan": "Rp. 500,000 - Rp. 999,999"\n        }';


--
-- Name: master_prodi; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.master_prodi (
    id_prodi uuid NOT NULL,
    kode_program_studi character(5) NOT NULL,
    nama_program_studi character varying(100) NOT NULL,
    status character(1) NOT NULL,
    id_jenjang_pendidikan smallint NOT NULL,
    nama_jenjang_pendidikan character varying(30)
);


--
-- Name: TABLE master_prodi; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.master_prodi IS 'GetProdi\n{\n            "id_prodi": "b1a89424-45fe-4b10-9ba3-113636e09f5e",\n            "kode_program_studi": "15901",\n            "nama_program_studi": "Pendidikan Profesi Bidan",\n            "status": "A",\n            "id_jenjang_pendidikan": "31",\n            "nama_jenjang_pendidikan": "Profesi"\n        }';


--
-- Name: COLUMN master_prodi.status; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_prodi.status IS 'A atau N';


--
-- Name: master_status_mahasiswa; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.master_status_mahasiswa (
    id_status_mahasiswa character(1) NOT NULL,
    nama_status_mahasiswa character varying(50)
);


--
-- Name: TABLE master_status_mahasiswa; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.master_status_mahasiswa IS 'GetStatusMahasiswa\n{\n            "id_status_mahasiswa": "N",\n            "nama_status_mahasiswa": "Non-Aktif                           "\n        },\n        {\n            "id_status_mahasiswa": "C",\n            "nama_status_mahasiswa": "Cuti"\n        },\n        {\n            "id_status_mahasiswa": "G",\n            "nama_status_mahasiswa": "Sedang Double Degree"\n        },\n        {\n            "id_status_mahasiswa": "M",\n            "nama_status_mahasiswa": "Kampus Merdeka"\n        },\n        {\n            "id_status_mahasiswa": "A",\n            "nama_status_mahasiswa": "Aktif"\n        }';


--
-- Name: master_tagihan_angkatan; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.master_tagihan_angkatan (
    id_tagihan_angkatan uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    id_angkatan_mahasiswa uuid,
    id_semester character(5),
    id_kode_pembayaran uuid,
    kode_rekening character varying(6),
    nama_rekening character varying,
    biaya character varying,
    id_tahun_akademik uuid,
    id_prodi uuid,
    nama_program_studi character varying
);


--
-- Name: COLUMN master_tagihan_angkatan.id_semester; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_tagihan_angkatan.id_semester IS 'id semester berlaku';


--
-- Name: master_tahun_akademik; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.master_tahun_akademik (
    id_semester character(5) NOT NULL,
    tahun_mulai numeric(4,0),
    "tahun selesai" numeric(4,0),
    nama_semester character varying(50),
    tgl_create date DEFAULT CURRENT_DATE,
    tgl_update date DEFAULT CURRENT_DATE,
    smt integer,
    status boolean,
    id_tahun_akademik uuid DEFAULT public.uuid_generate_v4() NOT NULL
);


--
-- Name: COLUMN master_tahun_akademik.id_semester; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_tahun_akademik.id_semester IS 'id semester\n20201';


--
-- Name: COLUMN master_tahun_akademik.tahun_mulai; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_tahun_akademik.tahun_mulai IS 'Tahun Mulai\n2020';


--
-- Name: COLUMN master_tahun_akademik."tahun selesai"; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_tahun_akademik."tahun selesai" IS 'Tahun selesai\n2021';


--
-- Name: COLUMN master_tahun_akademik.nama_semester; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_tahun_akademik.nama_semester IS 'Nama Semester\n2020/2021 Ganjil';


--
-- Name: COLUMN master_tahun_akademik.tgl_create; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_tahun_akademik.tgl_create IS 'Tanggal dibuat';


--
-- Name: COLUMN master_tahun_akademik.tgl_update; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_tahun_akademik.tgl_update IS 'tgl Update';


--
-- Name: COLUMN master_tahun_akademik.smt; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_tahun_akademik.smt IS 'semester \n1 /2';


--
-- Name: COLUMN master_tahun_akademik.status; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.master_tahun_akademik.status IS 'true false';


--
-- Name: master_wilayah; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.master_wilayah (
    id_wilayah character(6) NOT NULL,
    id_level_wilayah smallint,
    id_negara character varying(3),
    nama_wilayah character varying(100),
    id_induk_wilayah character(6)
);


--
-- Name: TABLE master_wilayah; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.master_wilayah IS 'GetWilayah\n {\n            "id_level_wilayah": 3,\n            "id_wilayah": "020804  ",\n            "id_negara": "ID",\n            "nama_wilayah": "Kec. Pangalengan"\n        },';


--
-- Name: matakuliah_kelas_mahasiswa; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.matakuliah_kelas_mahasiswa (
    id_matakuliah_kelas_mahasiswa uuid NOT NULL,
    id_prodi uuid NOT NULL,
    nama_program_studi character varying,
    id_matakuliah_krs_ditawarkan uuid NOT NULL,
    id_matkul uuid,
    nama_mata_kuliah character varying(200),
    id_semester character(5),
    id_master_kelas_mahasiswa uuid NOT NULL
);


--
-- Name: TABLE matakuliah_kelas_mahasiswa; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.matakuliah_kelas_mahasiswa IS 'detail kelas yang akan masuk dalam generate kelas';


--
-- Name: matakuliah_krs_ditawarkan; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.matakuliah_krs_ditawarkan (
    id_matakuliah_krs_ditawarkan uuid NOT NULL,
    id_waktu_krs uuid NOT NULL,
    id_semester_angkatan character(5),
    id_semester character(5),
    id_matakuliah_kurikulum uuid,
    id_matkul uuid,
    nama_mata_kuliah character varying(200),
    id_prodi uuid,
    nama_program_studi character varying,
    id_tahun_akademik_angkatan uuid,
    id_tahun_akademik uuid
);


--
-- Name: TABLE matakuliah_krs_ditawarkan; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.matakuliah_krs_ditawarkan IS 'matakuliah krs ditawarkan';


--
-- Name: COLUMN matakuliah_krs_ditawarkan.id_semester_angkatan; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.matakuliah_krs_ditawarkan.id_semester_angkatan IS 'id angkatan mahasiswa berlaku';


--
-- Name: COLUMN matakuliah_krs_ditawarkan.id_semester; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.matakuliah_krs_ditawarkan.id_semester IS 'id semester krs berlaku';


--
-- Name: matakuliah_kurikulum; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.matakuliah_kurikulum (
    id_matakuliah_kurikulum uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    id_kurikulum uuid NOT NULL,
    nama_kurikulum character varying(60),
    id_matkul uuid NOT NULL,
    nama_matkul character varying,
    semester numeric(2,0),
    id_semester character(5),
    semester_mulai_berlaku character varying,
    apakah_wajib numeric(1,0) DEFAULT 1,
    sks_mata_kuliah numeric(5,2) DEFAULT 0,
    sks_tatap_muka numeric(5,2) DEFAULT 0,
    sks_praktek numeric(5,2) DEFAULT 0,
    sks_praktek_lapangan numeric(5,2) DEFAULT 0,
    sks_simulasi numeric(5,2) DEFAULT 0,
    id_prodi uuid,
    id_tahun_akademik uuid,
    nama_program_studi character varying
);


--
-- Name: TABLE matakuliah_kurikulum; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.matakuliah_kurikulum IS 'Matakuliah Kurikulum';


--
-- Name: COLUMN matakuliah_kurikulum.id_kurikulum; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.matakuliah_kurikulum.id_kurikulum IS 'ID Kurikulum SP. Web Service: GetListKurikulum';


--
-- Name: COLUMN matakuliah_kurikulum.nama_kurikulum; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.matakuliah_kurikulum.nama_kurikulum IS 'Nama Matakuliah Kurikulum';


--
-- Name: COLUMN matakuliah_kurikulum.id_matkul; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.matakuliah_kurikulum.id_matkul IS 'Web Service: GetListMataKuliah';


--
-- Name: COLUMN matakuliah_kurikulum.nama_matkul; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.matakuliah_kurikulum.nama_matkul IS 'Nama Matakuliah';


--
-- Name: COLUMN matakuliah_kurikulum.semester; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.matakuliah_kurikulum.semester IS 'semester matakuliah (1,2,3...8)';


--
-- Name: COLUMN matakuliah_kurikulum.id_semester; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.matakuliah_kurikulum.id_semester IS 'id semester angkatan berlaku';


--
-- Name: COLUMN matakuliah_kurikulum.apakah_wajib; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.matakuliah_kurikulum.apakah_wajib IS '1:Wajib, 0:Tidak Wajib';


--
-- Name: matakuliah_remidi_ditawarkan; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.matakuliah_remidi_ditawarkan (
    id_matakuliah_remidi_ditawarkan uuid NOT NULL,
    id_waktu_remidi uuid NOT NULL,
    id_semester_angkatan character(5),
    id_semester character(5),
    id_matkul_kurikulum uuid,
    id_matkul uuid,
    nama_mata_kuliah character varying(200),
    id_prodi uuid,
    nama_program_studi character varying
);


--
-- Name: TABLE matakuliah_remidi_ditawarkan; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.matakuliah_remidi_ditawarkan IS 'matakuliah  remidi  ditawarkan';


--
-- Name: COLUMN matakuliah_remidi_ditawarkan.id_semester_angkatan; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.matakuliah_remidi_ditawarkan.id_semester_angkatan IS 'id angkatan mahasiswa berlaku';


--
-- Name: COLUMN matakuliah_remidi_ditawarkan.id_semester; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.matakuliah_remidi_ditawarkan.id_semester IS 'id semester krs berlaku';


--
-- Name: matakuliah_rencana_remidi_ditawarkan; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.matakuliah_rencana_remidi_ditawarkan (
    id_matakuliah_rencana_remidi_ditawarkan uuid NOT NULL,
    id_waktu_krs uuid NOT NULL,
    id_semester_angkatan character(5),
    id_semester character(5),
    id_matkul_kurikulum uuid,
    id_matkul uuid,
    nama_mata_kuliah character varying(200),
    id_prodi uuid,
    nama_program_studi character varying
);


--
-- Name: TABLE matakuliah_rencana_remidi_ditawarkan; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.matakuliah_rencana_remidi_ditawarkan IS 'matakuliah rencana remidi  ditawarkan';


--
-- Name: COLUMN matakuliah_rencana_remidi_ditawarkan.id_semester_angkatan; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.matakuliah_rencana_remidi_ditawarkan.id_semester_angkatan IS 'id angkatan mahasiswa berlaku';


--
-- Name: COLUMN matakuliah_rencana_remidi_ditawarkan.id_semester; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.matakuliah_rencana_remidi_ditawarkan.id_semester IS 'id semester krs berlaku';


--
-- Name: negara; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.negara (
    id_negara character(2) NOT NULL,
    nama_negara character varying(50) NOT NULL
);


--
-- Name: nilai; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.nilai (
    id_nilai uuid NOT NULL,
    id_prodi uuid NOT NULL,
    nama_program_studi character varying,
    id_semester character(5) NOT NULL,
    id_master_kegiatan_perkuliahan uuid NOT NULL,
    id_registrasi_mahasiswa uuid[] NOT NULL,
    nim character varying(24),
    nama_mahasiswa character(100),
    id_peserta_kelas_mahasiswa uuid NOT NULL,
    kelas character(5),
    nilai numeric(5,2) NOT NULL,
    tgl_nilai time without time zone NOT NULL,
    id_pegawai uuid NOT NULL,
    stat_nilai character(1) DEFAULT 1 NOT NULL,
    tgl_insert timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    validasi character(1) DEFAULT 0,
    id_dosen uuid
);


--
-- Name: TABLE nilai; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.nilai IS 'nilai mentah';


--
-- Name: COLUMN nilai.stat_nilai; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.nilai.stat_nilai IS '1 : reguler\n2 : remidi';


--
-- Name: COLUMN nilai.validasi; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.nilai.validasi IS '0 = belum validasi\n1 = validasi';


--
-- Name: parameter_absensi; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.parameter_absensi (
    id_parameter_penilaian uuid NOT NULL,
    id_master_parameter_penilaian uuid NOT NULL,
    id_prodi uuid,
    nama_program_studi character varying,
    id_semester character(5),
    id_master_kegiatan_perkuliahan uuid NOT NULL,
    prosentase numeric(8,2) NOT NULL,
    jumlah_kegiatan numeric(2,0) NOT NULL,
    nilai_huruf character(2)
);


--
-- Name: TABLE parameter_absensi; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.parameter_absensi IS 'parameter penilaian';


--
-- Name: COLUMN parameter_absensi.nilai_huruf; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.parameter_absensi.nilai_huruf IS 'Jika prosentase tidak terpenuhi';


--
-- Name: parameter_penilaian; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.parameter_penilaian (
    id_parameter_penilaian uuid NOT NULL,
    id_prodi uuid,
    nama_program_studi character varying,
    id_semester character(5),
    id_master_kegiatan_perkuliahan uuid NOT NULL,
    fungsi character(3) DEFAULT 'avg'::bpchar,
    prosentase numeric(8,2) NOT NULL,
    jumlah_kegiatan numeric(2,0) NOT NULL,
    id_master_parameter_penilaian uuid NOT NULL,
    nbl numeric(8,2),
    nilai_huruf character(2)
);


--
-- Name: TABLE parameter_penilaian; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.parameter_penilaian IS 'parameter penilaian';


--
-- Name: COLUMN parameter_penilaian.fungsi; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.parameter_penilaian.fungsi IS 'max\nsum\navg';


--
-- Name: COLUMN parameter_penilaian.nilai_huruf; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.parameter_penilaian.nilai_huruf IS 'jika tidak lebih dari nbl maka langsung dapat nilai huruf ini';


--
-- Name: periode_perkuliahan; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.periode_perkuliahan (
    id_periode_perkuliahan uuid NOT NULL,
    id_prodi uuid NOT NULL,
    nama_program_studi character varying,
    id_semester character(5),
    nama_semester character varying(50),
    jumlah_target_mahasiswa_baru integer,
    tanggal_awal_perkuliahan date,
    tanggal_akhir_perkuliahan date,
    calon_ikut_seleksi integer,
    calon_lulus_seleksi integer,
    daftar_sbg_mhs integer,
    pst_undur_diri integer,
    jml_mgu_kul integer,
    metode_kul character varying,
    metode_kul_eks character varying,
    tgl_create date DEFAULT CURRENT_DATE,
    last_update date DEFAULT CURRENT_DATE,
    status_sync character varying(10)
);


--
-- Name: TABLE periode_perkuliahan; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON TABLE siakad.periode_perkuliahan IS 'Periode Perkuliahan Program Studi';


--
-- Name: COLUMN periode_perkuliahan.id_periode_perkuliahan; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.periode_perkuliahan.id_periode_perkuliahan IS 'uuid';


--
-- Name: COLUMN periode_perkuliahan.id_prodi; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.periode_perkuliahan.id_prodi IS 'id Program studi';


--
-- Name: COLUMN periode_perkuliahan.nama_program_studi; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.periode_perkuliahan.nama_program_studi IS 'Nama Program Studi';


--
-- Name: COLUMN periode_perkuliahan.jumlah_target_mahasiswa_baru; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.periode_perkuliahan.jumlah_target_mahasiswa_baru IS 'Target Mahasiswa Baru';


--
-- Name: COLUMN periode_perkuliahan.tanggal_awal_perkuliahan; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.periode_perkuliahan.tanggal_awal_perkuliahan IS 'Tanggal Dimulai Semester';


--
-- Name: COLUMN periode_perkuliahan.calon_ikut_seleksi; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.periode_perkuliahan.calon_ikut_seleksi IS 'calon maba';


--
-- Name: COLUMN periode_perkuliahan.calon_lulus_seleksi; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.periode_perkuliahan.calon_lulus_seleksi IS 'calon lulus seleksi';


--
-- Name: COLUMN periode_perkuliahan.daftar_sbg_mhs; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.periode_perkuliahan.daftar_sbg_mhs IS 'daftar registrasi';


--
-- Name: COLUMN periode_perkuliahan.pst_undur_diri; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.periode_perkuliahan.pst_undur_diri IS 'mahasiswa mengundurkan diri';


--
-- Name: COLUMN periode_perkuliahan.jml_mgu_kul; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.periode_perkuliahan.jml_mgu_kul IS 'Jumlah minggu kuliah';


--
-- Name: COLUMN periode_perkuliahan.tgl_create; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.periode_perkuliahan.tgl_create IS 'Tanggal Insert';


--
-- Name: COLUMN periode_perkuliahan.last_update; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.periode_perkuliahan.last_update IS 'tgl update';


--
-- Name: COLUMN periode_perkuliahan.status_sync; Type: COMMENT; Schema: siakad; Owner: -
--

COMMENT ON COLUMN siakad.periode_perkuliahan.status_sync IS 'sudah sync\nbelum sync';


--
-- Name: peserta_absensi; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.peserta_absensi (
    id_peserta_absensi uuid NOT NULL,
    id_absensi_perkuliahan uuid NOT NULL,
    id_registrasi_mahasiswa uuid[],
    tgl_insert timestamp without time zone,
    tgl_absen time without time zone NOT NULL
);


--
-- Name: peserta_kelas_mahasiswa; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.peserta_kelas_mahasiswa (
    id_peserta_kelas_mahasiswa uuid NOT NULL,
    id_prodi uuid NOT NULL,
    nama_program_studi character varying,
    id_semester character(5),
    id_registrasi_mahasiswa uuid[],
    id_mahasiswa uuid,
    nama_mahasiswa character(100),
    nim character varying(24),
    id_master_kelas_mahasiswa uuid,
    kelas character(5),
    id_matakuliah_krs_ditawarkan uuid,
    id_lokasi_perkuliahan uuid NOT NULL
);


--
-- Name: waktu_krs; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.waktu_krs (
    id_waktu_krs uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    nama_krs character varying,
    id_prodi uuid,
    nama_program_studi character varying,
    id_semester character(5),
    id_tahun_akademik uuid,
    nama_semester character varying(50),
    status_data character varying DEFAULT 'Aktif'::character varying,
    tgl_mulai timestamp without time zone,
    tgl_selesai timestamp without time zone,
    tgl_toleransi_mulai timestamp without time zone,
    tgl_toleransi_selesai timestamp without time zone
);


--
-- Name: waktu_remidi; Type: TABLE; Schema: siakad; Owner: -
--

CREATE TABLE siakad.waktu_remidi (
    id_waktu_remidi uuid NOT NULL,
    nama_remidi character varying,
    id_prodi uuid,
    nama_program_studi character varying,
    id_semester character(5),
    tgl_mulai time without time zone,
    tgl_selesai time without time zone,
    tgl_tolerasi_mulai time without time zone,
    tgl_toleransi_selesai time without time zone
);


--
-- Name: mahasiswa_skripsi; Type: TABLE; Schema: skripsi; Owner: -
--

CREATE TABLE skripsi.mahasiswa_skripsi (
    id_mahasiswa_skripsi uuid NOT NULL,
    id_prodi uuid NOT NULL,
    nama_program_studi character varying,
    id_semester character(5) NOT NULL,
    id_semester_selesai character(5),
    judul character varying,
    judul_inggris character varying,
    status character(1) DEFAULT 1,
    id_jenis_aktivitas numeric NOT NULL
);


--
-- Name: COLUMN mahasiswa_skripsi.id_semester; Type: COMMENT; Schema: skripsi; Owner: -
--

COMMENT ON COLUMN skripsi.mahasiswa_skripsi.id_semester IS 'id_semester daftar';


--
-- Name: COLUMN mahasiswa_skripsi.status; Type: COMMENT; Schema: skripsi; Owner: -
--

COMMENT ON COLUMN skripsi.mahasiswa_skripsi.status IS '1 = aktif\n0 = tidak aktif';


--
-- Name: COLUMN mahasiswa_skripsi.id_jenis_aktivitas; Type: COMMENT; Schema: skripsi; Owner: -
--

COMMENT ON COLUMN skripsi.mahasiswa_skripsi.id_jenis_aktivitas IS 'ID Jenis Aktivitas. Web Service : GetJenisAktivitasMahasiswa';


--
-- Name: pembimbing_mahasiswa; Type: TABLE; Schema: skripsi; Owner: -
--

CREATE TABLE skripsi.pembimbing_mahasiswa (
    id_pembimbing_mahasiswa uuid NOT NULL,
    id_mahasiswa_skripsi uuid NOT NULL,
    id_kategori_kegiatan character(6) NOT NULL,
    id_dosen uuid NOT NULL,
    pemimbing_ke integer NOT NULL
);


--
-- Name: COLUMN pembimbing_mahasiswa.id_kategori_kegiatan; Type: COMMENT; Schema: skripsi; Owner: -
--

COMMENT ON COLUMN skripsi.pembimbing_mahasiswa.id_kategori_kegiatan IS 'Web Service: GetKategoriKegiatan';


--
-- Data for Name: master_dosen_wali; Type: TABLE DATA; Schema: perwalian; Owner: -
--

\i $$PATH$$/4001.dat

--
-- Data for Name: penguji_mahasiswa; Type: TABLE DATA; Schema: perwalian; Owner: -
--

\i $$PATH$$/4002.dat

--
-- Data for Name: pesan_perwalian; Type: TABLE DATA; Schema: perwalian; Owner: -
--

\i $$PATH$$/4003.dat

--
-- Data for Name: tran_perwalian; Type: TABLE DATA; Schema: perwalian; Owner: -
--

\i $$PATH$$/4004.dat

--
-- Data for Name: waktu_perwalian; Type: TABLE DATA; Schema: perwalian; Owner: -
--

\i $$PATH$$/4005.dat

--
-- Data for Name: absensi_perkuliahan; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4006.dat

--
-- Data for Name: aktivitas_perkuliahan_mahasiswa; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4007.dat

--
-- Data for Name: biodata_mahasiswa; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4008.dat

--
-- Data for Name: kurikulum; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4010.dat

--
-- Data for Name: list_mahasiswa; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4011.dat

--
-- Data for Name: lokasi_perkuliahan; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4012.dat

--
-- Data for Name: mahasiswa_angkatan; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4055.dat

--
-- Data for Name: mahasiswa_krs; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4013.dat

--
-- Data for Name: mahasiswa_kurikulum; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4014.dat

--
-- Data for Name: mahasiswa_remidi; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4015.dat

--
-- Data for Name: mahasiswa_rencana_remidi; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4016.dat

--
-- Data for Name: master_agama; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4038.dat

--
-- Data for Name: master_alat_transportasi; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4049.dat

--
-- Data for Name: master_angkatan_mahasiswa; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4054.dat

--
-- Data for Name: master_jalur_masuk; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4039.dat

--
-- Data for Name: master_jenis_keluar; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4040.dat

--
-- Data for Name: master_jenis_matakuliah; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4053.dat

--
-- Data for Name: master_jenis_perndaftaran; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4041.dat

--
-- Data for Name: master_jenis_prestasi; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4051.dat

--
-- Data for Name: master_jenis_tinggal; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4042.dat

--
-- Data for Name: master_jenjang_pendidikan; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4043.dat

--
-- Data for Name: master_kegiatan_perkuliahan; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4017.dat

--
-- Data for Name: master_kelas_mahasiswa; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4018.dat

--
-- Data for Name: master_kode_pembayaran; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4009.dat

--
-- Data for Name: master_matakuliah; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4021.dat

--
-- Data for Name: master_parameter_penilaian; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4019.dat

--
-- Data for Name: master_pekerjaan; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4047.dat

--
-- Data for Name: master_pembiayaan_mahasiswa; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4050.dat

--
-- Data for Name: master_penghasilan; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4046.dat

--
-- Data for Name: master_prodi; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4048.dat

--
-- Data for Name: master_status_mahasiswa; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4045.dat

--
-- Data for Name: master_tagihan_angkatan; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4020.dat

--
-- Data for Name: master_tahun_akademik; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4036.dat

--
-- Data for Name: master_wilayah; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4044.dat

--
-- Data for Name: matakuliah_kelas_mahasiswa; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4022.dat

--
-- Data for Name: matakuliah_krs_ditawarkan; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4023.dat

--
-- Data for Name: matakuliah_kurikulum; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4026.dat

--
-- Data for Name: matakuliah_remidi_ditawarkan; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4024.dat

--
-- Data for Name: matakuliah_rencana_remidi_ditawarkan; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4025.dat

--
-- Data for Name: negara; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4052.dat

--
-- Data for Name: nilai; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4027.dat

--
-- Data for Name: parameter_absensi; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4028.dat

--
-- Data for Name: parameter_penilaian; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4029.dat

--
-- Data for Name: periode_perkuliahan; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4037.dat

--
-- Data for Name: peserta_absensi; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4030.dat

--
-- Data for Name: peserta_kelas_mahasiswa; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4031.dat

--
-- Data for Name: waktu_krs; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4032.dat

--
-- Data for Name: waktu_remidi; Type: TABLE DATA; Schema: siakad; Owner: -
--

\i $$PATH$$/4033.dat

--
-- Data for Name: mahasiswa_skripsi; Type: TABLE DATA; Schema: skripsi; Owner: -
--

\i $$PATH$$/4034.dat

--
-- Data for Name: pembimbing_mahasiswa; Type: TABLE DATA; Schema: skripsi; Owner: -
--

\i $$PATH$$/4035.dat

--
-- Name: master_dosen_wali pk_master_dosen_wali; Type: CONSTRAINT; Schema: perwalian; Owner: -
--

ALTER TABLE ONLY perwalian.master_dosen_wali
    ADD CONSTRAINT pk_master_dosen_wali PRIMARY KEY (id_master_dosen_wali);


--
-- Name: penguji_mahasiswa pk_pembimbing_mahasiswa; Type: CONSTRAINT; Schema: perwalian; Owner: -
--

ALTER TABLE ONLY perwalian.penguji_mahasiswa
    ADD CONSTRAINT pk_pembimbing_mahasiswa PRIMARY KEY (id_penguji_mahasiswa);


--
-- Name: pesan_perwalian pk_pesan_perwalian; Type: CONSTRAINT; Schema: perwalian; Owner: -
--

ALTER TABLE ONLY perwalian.pesan_perwalian
    ADD CONSTRAINT pk_pesan_perwalian PRIMARY KEY (id_pesan_perwalian);


--
-- Name: tran_perwalian pk_tran_perwalian; Type: CONSTRAINT; Schema: perwalian; Owner: -
--

ALTER TABLE ONLY perwalian.tran_perwalian
    ADD CONSTRAINT pk_tran_perwalian PRIMARY KEY (id_tran_perwalian);


--
-- Name: waktu_perwalian pk_waktu_krs; Type: CONSTRAINT; Schema: perwalian; Owner: -
--

ALTER TABLE ONLY perwalian.waktu_perwalian
    ADD CONSTRAINT pk_waktu_krs PRIMARY KEY (id_waktu_perwalian);


--
-- Name: master_matakuliah master_matakuliah_pk; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_matakuliah
    ADD CONSTRAINT master_matakuliah_pk PRIMARY KEY (kode_mata_kuliah, nama_mata_kuliah, id_prodi, sks_mata_kuliah, sks_tatap_muka, sks_praktek, sks_praktek_lapangan, sks_simulasi);


--
-- Name: negara negara_pkey; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.negara
    ADD CONSTRAINT negara_pkey PRIMARY KEY (id_negara);


--
-- Name: absensi_perkuliahan pk_absensi_perkuliahan; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.absensi_perkuliahan
    ADD CONSTRAINT pk_absensi_perkuliahan PRIMARY KEY (id_absensi_perkuliahan);


--
-- Name: aktivitas_perkuliahan_mahasiswa pk_aktivitas_perkuliahan_mahasiswa; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.aktivitas_perkuliahan_mahasiswa
    ADD CONSTRAINT pk_aktivitas_perkuliahan_mahasiswa PRIMARY KEY (id_aktivitas_perkuliahan_mahasiswa);


--
-- Name: biodata_mahasiswa pk_biodata_mahasiswa; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.biodata_mahasiswa
    ADD CONSTRAINT pk_biodata_mahasiswa PRIMARY KEY (id_mahasiswa);


--
-- Name: master_jenis_matakuliah pk_id_jenis_mata_kuliah; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_jenis_matakuliah
    ADD CONSTRAINT pk_id_jenis_mata_kuliah PRIMARY KEY (id_jenis_mata_kuliah);


--
-- Name: master_kode_pembayaran pk_kode_pembayaran; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_kode_pembayaran
    ADD CONSTRAINT pk_kode_pembayaran PRIMARY KEY (id_kode_pembayaran);


--
-- Name: kurikulum pk_kurikulum; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.kurikulum
    ADD CONSTRAINT pk_kurikulum PRIMARY KEY (id_kurikulum);


--
-- Name: list_mahasiswa pk_list_mahasiswa; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.list_mahasiswa
    ADD CONSTRAINT pk_list_mahasiswa PRIMARY KEY (id_registrasi_mahasiswa);


--
-- Name: lokasi_perkuliahan pk_lokasi_perkuliahan; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.lokasi_perkuliahan
    ADD CONSTRAINT pk_lokasi_perkuliahan PRIMARY KEY (id_lokasi_perkuliahan);


--
-- Name: mahasiswa_angkatan pk_mahasiswa_angkatan; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.mahasiswa_angkatan
    ADD CONSTRAINT pk_mahasiswa_angkatan PRIMARY KEY (id_mahasiswa_angkatan);


--
-- Name: mahasiswa_krs pk_mahasiswa_krs; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.mahasiswa_krs
    ADD CONSTRAINT pk_mahasiswa_krs PRIMARY KEY (id_mahasiswa_krs);


--
-- Name: mahasiswa_rencana_remidi pk_mahasiswa_krs_0; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.mahasiswa_rencana_remidi
    ADD CONSTRAINT pk_mahasiswa_krs_0 PRIMARY KEY (id_mahasiswa_krs);


--
-- Name: mahasiswa_remidi pk_mahasiswa_krs_1; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.mahasiswa_remidi
    ADD CONSTRAINT pk_mahasiswa_krs_1 PRIMARY KEY (id_mahasiswa_remidi);


--
-- Name: mahasiswa_kurikulum pk_mahasiswa_kurikulum; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.mahasiswa_kurikulum
    ADD CONSTRAINT pk_mahasiswa_kurikulum PRIMARY KEY (id_mahasiswa_kurikulum);


--
-- Name: master_agama pk_master_agama; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_agama
    ADD CONSTRAINT pk_master_agama PRIMARY KEY (id_agama);


--
-- Name: master_alat_transportasi pk_master_alat_transportasi; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_alat_transportasi
    ADD CONSTRAINT pk_master_alat_transportasi PRIMARY KEY (id_alat_transportasi);


--
-- Name: master_angkatan_mahasiswa pk_master_angakatan_mahasiswa; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_angkatan_mahasiswa
    ADD CONSTRAINT pk_master_angakatan_mahasiswa PRIMARY KEY (id_angkatan_mahasiswa);


--
-- Name: master_jalur_masuk pk_master_jalur_masuk; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_jalur_masuk
    ADD CONSTRAINT pk_master_jalur_masuk PRIMARY KEY (id_jalur_masuk);


--
-- Name: master_jenis_keluar pk_master_jenis_keluar; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_jenis_keluar
    ADD CONSTRAINT pk_master_jenis_keluar PRIMARY KEY (id_jenis_keluar);


--
-- Name: master_jenis_perndaftaran pk_master_jenis_perndaftaran; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_jenis_perndaftaran
    ADD CONSTRAINT pk_master_jenis_perndaftaran PRIMARY KEY (id_jenis_daftar);


--
-- Name: master_jenis_prestasi pk_master_jenis_prestasi; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_jenis_prestasi
    ADD CONSTRAINT pk_master_jenis_prestasi PRIMARY KEY (id_jenis_prestasi);


--
-- Name: master_jenis_tinggal pk_master_jenis_tinggal; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_jenis_tinggal
    ADD CONSTRAINT pk_master_jenis_tinggal PRIMARY KEY (id_jenis_tinggal);


--
-- Name: master_jenjang_pendidikan pk_master_jenjang_pendidikan; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_jenjang_pendidikan
    ADD CONSTRAINT pk_master_jenjang_pendidikan PRIMARY KEY (id_jenjang_didik);


--
-- Name: master_kegiatan_perkuliahan pk_master_kegiatan_perkuliahan; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_kegiatan_perkuliahan
    ADD CONSTRAINT pk_master_kegiatan_perkuliahan PRIMARY KEY (id_master_kegiatan_perkuliahan);


--
-- Name: master_kelas_mahasiswa pk_master_kelompok_sgd; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_kelas_mahasiswa
    ADD CONSTRAINT pk_master_kelompok_sgd PRIMARY KEY (id_master_kelas_mahasiswa);


--
-- Name: master_pekerjaan pk_master_pekerjaan; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_pekerjaan
    ADD CONSTRAINT pk_master_pekerjaan PRIMARY KEY (id_pekerjaan);


--
-- Name: master_pembiayaan_mahasiswa pk_master_pembiayaan_mahasiswa; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_pembiayaan_mahasiswa
    ADD CONSTRAINT pk_master_pembiayaan_mahasiswa PRIMARY KEY (id_pembiayaan);


--
-- Name: master_penghasilan pk_master_penghasilan; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_penghasilan
    ADD CONSTRAINT pk_master_penghasilan PRIMARY KEY (id_penghasilan);


--
-- Name: master_prodi pk_master_prodi; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_prodi
    ADD CONSTRAINT pk_master_prodi PRIMARY KEY (id_prodi);


--
-- Name: master_status_mahasiswa pk_master_status_mahasiswa; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_status_mahasiswa
    ADD CONSTRAINT pk_master_status_mahasiswa PRIMARY KEY (id_status_mahasiswa);


--
-- Name: master_tagihan_angkatan pk_master_tagihan_angkatan; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_tagihan_angkatan
    ADD CONSTRAINT pk_master_tagihan_angkatan PRIMARY KEY (id_tagihan_angkatan);


--
-- Name: master_tahun_akademik pk_master_tahun_akademik; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_tahun_akademik
    ADD CONSTRAINT pk_master_tahun_akademik PRIMARY KEY (id_tahun_akademik);


--
-- Name: master_wilayah pk_master_wilayah; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_wilayah
    ADD CONSTRAINT pk_master_wilayah PRIMARY KEY (id_wilayah);


--
-- Name: matakuliah_kelas_mahasiswa pk_matakuliah_kelas_mahasiswa; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.matakuliah_kelas_mahasiswa
    ADD CONSTRAINT pk_matakuliah_kelas_mahasiswa PRIMARY KEY (id_matakuliah_kelas_mahasiswa);


--
-- Name: matakuliah_krs_ditawarkan pk_matakuliah_krs_ditawarkan; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.matakuliah_krs_ditawarkan
    ADD CONSTRAINT pk_matakuliah_krs_ditawarkan PRIMARY KEY (id_matakuliah_krs_ditawarkan);


--
-- Name: matakuliah_rencana_remidi_ditawarkan pk_matakuliah_krs_ditawarkan_0; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.matakuliah_rencana_remidi_ditawarkan
    ADD CONSTRAINT pk_matakuliah_krs_ditawarkan_0 PRIMARY KEY (id_matakuliah_rencana_remidi_ditawarkan);


--
-- Name: matakuliah_remidi_ditawarkan pk_matakuliah_krs_ditawarkan_1; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.matakuliah_remidi_ditawarkan
    ADD CONSTRAINT pk_matakuliah_krs_ditawarkan_1 PRIMARY KEY (id_matakuliah_remidi_ditawarkan);


--
-- Name: matakuliah_kurikulum pk_matkul_kurikulum; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.matakuliah_kurikulum
    ADD CONSTRAINT pk_matkul_kurikulum PRIMARY KEY (id_matakuliah_kurikulum);


--
-- Name: nilai pk_nilai; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.nilai
    ADD CONSTRAINT pk_nilai PRIMARY KEY (id_nilai);


--
-- Name: parameter_penilaian pk_parameter_penilaian; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.parameter_penilaian
    ADD CONSTRAINT pk_parameter_penilaian PRIMARY KEY (id_parameter_penilaian);


--
-- Name: master_parameter_penilaian pk_parameter_penilaian_0; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_parameter_penilaian
    ADD CONSTRAINT pk_parameter_penilaian_0 PRIMARY KEY (id_master_parameter_penilaian);


--
-- Name: parameter_absensi pk_parameter_penilaian_1; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.parameter_absensi
    ADD CONSTRAINT pk_parameter_penilaian_1 PRIMARY KEY (id_parameter_penilaian);


--
-- Name: periode_perkuliahan pk_periode_perkuliahan; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.periode_perkuliahan
    ADD CONSTRAINT pk_periode_perkuliahan PRIMARY KEY (id_periode_perkuliahan);


--
-- Name: peserta_absensi pk_peserta_absensi; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.peserta_absensi
    ADD CONSTRAINT pk_peserta_absensi PRIMARY KEY (id_peserta_absensi);


--
-- Name: peserta_kelas_mahasiswa pk_peserta_kelas_mahasiswa; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.peserta_kelas_mahasiswa
    ADD CONSTRAINT pk_peserta_kelas_mahasiswa PRIMARY KEY (id_peserta_kelas_mahasiswa);


--
-- Name: waktu_krs pk_waktu_krs; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.waktu_krs
    ADD CONSTRAINT pk_waktu_krs PRIMARY KEY (id_waktu_krs);


--
-- Name: waktu_remidi pk_waktu_krs_0; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.waktu_remidi
    ADD CONSTRAINT pk_waktu_krs_0 PRIMARY KEY (id_waktu_remidi);


--
-- Name: biodata_mahasiswa unq_biodata_mahasiswa_id_agama; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.biodata_mahasiswa
    ADD CONSTRAINT unq_biodata_mahasiswa_id_agama UNIQUE (id_agama);


--
-- Name: biodata_mahasiswa unq_biodata_mahasiswa_nama_mahasiswa; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.biodata_mahasiswa
    ADD CONSTRAINT unq_biodata_mahasiswa_nama_mahasiswa UNIQUE (nama_mahasiswa);


--
-- Name: master_kode_pembayaran unq_kode_pembayaran_kode_rekening; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.master_kode_pembayaran
    ADD CONSTRAINT unq_kode_pembayaran_kode_rekening UNIQUE (kode_rekening);


--
-- Name: periode_perkuliahan unq_periode_perkuliahan_id_semester; Type: CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.periode_perkuliahan
    ADD CONSTRAINT unq_periode_perkuliahan_id_semester UNIQUE (id_semester);


--
-- Name: mahasiswa_skripsi pk_mahasiswa_skripsi; Type: CONSTRAINT; Schema: skripsi; Owner: -
--

ALTER TABLE ONLY skripsi.mahasiswa_skripsi
    ADD CONSTRAINT pk_mahasiswa_skripsi PRIMARY KEY (id_mahasiswa_skripsi);


--
-- Name: pembimbing_mahasiswa pk_pembimbing_mahasiswa; Type: CONSTRAINT; Schema: skripsi; Owner: -
--

ALTER TABLE ONLY skripsi.pembimbing_mahasiswa
    ADD CONSTRAINT pk_pembimbing_mahasiswa PRIMARY KEY (id_pembimbing_mahasiswa);


--
-- Name: pesan_perwalian fk_pesan_perwalian_tran_perwalian; Type: FK CONSTRAINT; Schema: perwalian; Owner: -
--

ALTER TABLE ONLY perwalian.pesan_perwalian
    ADD CONSTRAINT fk_pesan_perwalian_tran_perwalian FOREIGN KEY (id_tran_perwalian) REFERENCES perwalian.tran_perwalian(id_tran_perwalian);


--
-- Name: tran_perwalian fk_tran_perwalian_waktu_perwalian; Type: FK CONSTRAINT; Schema: perwalian; Owner: -
--

ALTER TABLE ONLY perwalian.tran_perwalian
    ADD CONSTRAINT fk_tran_perwalian_waktu_perwalian FOREIGN KEY (id_waktu_perwalian) REFERENCES perwalian.waktu_perwalian(id_waktu_perwalian);


--
-- Name: mahasiswa_krs fk_mahasiswa_krs_matakuliah_krs_ditawarkan; Type: FK CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.mahasiswa_krs
    ADD CONSTRAINT fk_mahasiswa_krs_matakuliah_krs_ditawarkan FOREIGN KEY (id_matakuliah_krs_ditawarkan) REFERENCES siakad.matakuliah_krs_ditawarkan(id_matakuliah_krs_ditawarkan);


--
-- Name: mahasiswa_remidi fk_mahasiswa_remidi_matakuliah_remidi_ditawarkan; Type: FK CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.mahasiswa_remidi
    ADD CONSTRAINT fk_mahasiswa_remidi_matakuliah_remidi_ditawarkan FOREIGN KEY (id_matakuliah_remidi_ditawarkan) REFERENCES siakad.matakuliah_remidi_ditawarkan(id_matakuliah_remidi_ditawarkan);


--
-- Name: mahasiswa_rencana_remidi fk_mahasiswa_rencana_remidi_matakuliah_rencana_remidi_ditawarka; Type: FK CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.mahasiswa_rencana_remidi
    ADD CONSTRAINT fk_mahasiswa_rencana_remidi_matakuliah_rencana_remidi_ditawarka FOREIGN KEY (id_matakuliah_rencana_remidi_ditawarkan) REFERENCES siakad.matakuliah_rencana_remidi_ditawarkan(id_matakuliah_rencana_remidi_ditawarkan);


--
-- Name: mahasiswa_remidi fk_mahasiswa_rencana_remidi_matakuliah_rencana_remidi_ditawarka; Type: FK CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.mahasiswa_remidi
    ADD CONSTRAINT fk_mahasiswa_rencana_remidi_matakuliah_rencana_remidi_ditawarka FOREIGN KEY (id_matakuliah_remidi_ditawarkan) REFERENCES siakad.matakuliah_rencana_remidi_ditawarkan(id_matakuliah_rencana_remidi_ditawarkan);


--
-- Name: matakuliah_kelas_mahasiswa fk_matakuliah_kelas_mahasiswa_master_kelas_mahasiswa; Type: FK CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.matakuliah_kelas_mahasiswa
    ADD CONSTRAINT fk_matakuliah_kelas_mahasiswa_master_kelas_mahasiswa FOREIGN KEY (id_master_kelas_mahasiswa) REFERENCES siakad.master_kelas_mahasiswa(id_master_kelas_mahasiswa);


--
-- Name: matakuliah_krs_ditawarkan fk_matakuliah_krs_ditawarkan_matkul_kurikulum; Type: FK CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.matakuliah_krs_ditawarkan
    ADD CONSTRAINT fk_matakuliah_krs_ditawarkan_matkul_kurikulum FOREIGN KEY (id_matakuliah_kurikulum) REFERENCES siakad.matakuliah_kurikulum(id_matakuliah_kurikulum);


--
-- Name: matakuliah_rencana_remidi_ditawarkan fk_matakuliah_krs_ditawarkan_matkul_kurikulum_0; Type: FK CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.matakuliah_rencana_remidi_ditawarkan
    ADD CONSTRAINT fk_matakuliah_krs_ditawarkan_matkul_kurikulum_0 FOREIGN KEY (id_matkul_kurikulum) REFERENCES siakad.matakuliah_kurikulum(id_matakuliah_kurikulum);


--
-- Name: matakuliah_remidi_ditawarkan fk_matakuliah_krs_ditawarkan_matkul_kurikulum_1; Type: FK CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.matakuliah_remidi_ditawarkan
    ADD CONSTRAINT fk_matakuliah_krs_ditawarkan_matkul_kurikulum_1 FOREIGN KEY (id_matkul_kurikulum) REFERENCES siakad.matakuliah_kurikulum(id_matakuliah_kurikulum);


--
-- Name: matakuliah_remidi_ditawarkan fk_matakuliah_remidi_ditawarkan_waktu_remidi; Type: FK CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.matakuliah_remidi_ditawarkan
    ADD CONSTRAINT fk_matakuliah_remidi_ditawarkan_waktu_remidi FOREIGN KEY (id_waktu_remidi) REFERENCES siakad.waktu_remidi(id_waktu_remidi);


--
-- Name: parameter_absensi fk_parameter_absensi_master_parameter_penilaian; Type: FK CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.parameter_absensi
    ADD CONSTRAINT fk_parameter_absensi_master_parameter_penilaian FOREIGN KEY (id_master_parameter_penilaian) REFERENCES siakad.master_parameter_penilaian(id_master_parameter_penilaian);


--
-- Name: parameter_penilaian fk_parameter_penilaian_master_parameter_penilaian; Type: FK CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.parameter_penilaian
    ADD CONSTRAINT fk_parameter_penilaian_master_parameter_penilaian FOREIGN KEY (id_master_parameter_penilaian) REFERENCES siakad.master_parameter_penilaian(id_master_parameter_penilaian);


--
-- Name: peserta_absensi fk_peserta_absensi_absensi_perkuliahan; Type: FK CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.peserta_absensi
    ADD CONSTRAINT fk_peserta_absensi_absensi_perkuliahan FOREIGN KEY (id_absensi_perkuliahan) REFERENCES siakad.absensi_perkuliahan(id_absensi_perkuliahan);


--
-- Name: peserta_kelas_mahasiswa fk_peserta_kelas_mahasiswa_lokasi_perkuliahan; Type: FK CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.peserta_kelas_mahasiswa
    ADD CONSTRAINT fk_peserta_kelas_mahasiswa_lokasi_perkuliahan FOREIGN KEY (id_lokasi_perkuliahan) REFERENCES siakad.lokasi_perkuliahan(id_lokasi_perkuliahan);


--
-- Name: peserta_kelas_mahasiswa fk_peserta_kelas_mahasiswa_master_kelas_mahasiswa; Type: FK CONSTRAINT; Schema: siakad; Owner: -
--

ALTER TABLE ONLY siakad.peserta_kelas_mahasiswa
    ADD CONSTRAINT fk_peserta_kelas_mahasiswa_master_kelas_mahasiswa FOREIGN KEY (id_master_kelas_mahasiswa) REFERENCES siakad.master_kelas_mahasiswa(id_master_kelas_mahasiswa);


--
-- PostgreSQL database dump complete
--

